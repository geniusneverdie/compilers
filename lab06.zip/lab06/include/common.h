#pragma once

enum dump_type_t
{
    TOKENS,
    AST,
    IR,
    ASM
};