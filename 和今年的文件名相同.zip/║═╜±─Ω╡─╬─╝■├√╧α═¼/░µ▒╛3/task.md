# Task

1. 函数参数数组维度初始化
2. 超过范围的offset