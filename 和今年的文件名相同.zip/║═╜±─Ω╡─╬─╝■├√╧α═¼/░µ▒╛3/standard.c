int main() {
    float a = 10.0;
    float b = 1.0;
    a = a + b;
    a = a - b;
    a = a * b;
    a = a / b;
    a = a < b;
    a = a > b;
    a = a <= b;
    a = a >= b;
}