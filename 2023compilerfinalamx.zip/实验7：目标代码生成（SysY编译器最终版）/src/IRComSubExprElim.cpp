#include "IRComSubExprElim.h"
#include <queue>
#include "Instruction.h"

IRComSubExprElim::IRComSubExprElim(Unit *unit)
{
    this->unit = unit;
}

IRComSubExprElim::~IRComSubExprElim()
{
}

bool IRComSubExprElim::skip(Instruction *inst)
{
    /**
     * 判断当前指令是否可以当成一个表达式
     * 当前只将二元运算指令当作表达式
     * 纯函数及一些一元指令也可当作表达式
     */
    if (dynamic_cast<BinaryInstruction *>(inst) != nullptr)
        return false;
    return true;
}

bool IRComSubExprElim::localCSE(Function *func)
{
    bool result = true;
    std::vector<Expr> exprs;
    for (auto block = func->begin(); block != func->end(); block++)
    {
        exprs.clear();
        for (auto inst = (*block)->begin(); inst != (*block)->end(); inst = inst->getNext())
        {
            if (skip(inst))
                continue;
            auto preInstIt = std::find(exprs.begin(), exprs.end(), Expr(inst));
            if (preInstIt != exprs.end())
            {
                //todo
                // 获取前一个指令
    Instruction* preInst = inst->getPrev();

    // 获取当前指令的def
    Operand* currentDef = inst->getDef();

    // 获取前一个指令的def
    Operand* preDef = preInst->getDef();

    // 替换对当前指令def的use成为对前一个指令def的use
    inst->replaceUse(currentDef, preDef);

    // 删除当前指令
    inst->remove();

            }
            
        }
    }
    return result;
}
   

            //}
           // else
             //   exprs.emplace_back(inst);
            /**
             * 这里不需要考虑表达式注销的问题
             * 因为ir是ssa形式的代码，目前来说应该不会有这样的情况，这种是错的
             * a = b + c
             * b = d + f
             */

bool IRComSubExprElim::globalCSE(Function *func)
{
    exprVec.clear();
    ins2Expr.clear();
    genBB.clear();
    killBB.clear();
    inBB.clear();
    outBB.clear();

    bool result = true; 
    calGenKill(func);
    calInOut(func);
    result = removeGlobalCSE(func);
    return result;
}

void IRComSubExprElim::calGenKill(Function *func)
{
    // 计算gen
    for (auto block = func->begin(); block != func->end(); block++)
    {
        for (auto inst = (*block)->begin(); inst != (*block)->end(); inst = inst->getNext())
        {
            if (skip(inst))
                continue;
            Expr expr(inst);
            // 对于表达式a + b，我们只需要全局记录一次，重复出现的话，用同一个id即可
            auto it = find(exprVec.begin(), exprVec.end(), expr);
            int ind = it - exprVec.begin();
            if (it == exprVec.end())
            {
                exprVec.push_back(expr);
            }
            ins2Expr[inst] = ind;
            genBB[*block].insert(ind);
            /*
                一个基本块内不会出现这种 t1 = t2 + t3
                                       t2 = ...
                所以这里，之后gen的表达式不会kill掉已经gen的表达式
                就算是phi指令，也是并行取值，所以问题不大哦
            */
        }
    }
    // 计算kill
    for (auto block = func->begin(); block != func->end(); block++)
    {
        for (auto inst = (*block)->begin(); inst != (*block)->end(); inst = inst->getNext())
        {
            if (inst->getDef() != nullptr)
            {
                for (auto useInst : inst->getDef()->getUse())
                {
                    if (!skip(useInst))
                        killBB[*block].insert(ins2Expr[useInst]);
                }
            }
        }
    }
}


void IRComSubExprElim::calInOut(Function *func)
{
    std::set<int> U;
    for (size_t i = 0; i < exprVec.size(); i++)
        U.insert(i);
    auto entry = func->getEntry();
    inBB[entry].clear();
    outBB[entry] = genBB[entry];
    // 初始化除entry外的基本块的out为U
    std::set<BasicBlock *> workList;
    for (auto block = func->begin(); block != func->end(); block++)
    {
        if (*block != entry) {
            outBB[*block] = U;
            workList.insert(*block);
        }
    }
    // 不断迭代直到收敛
    while (!workList.empty())
    {
        auto block = *workList.begin();
        workList.erase(workList.begin());
        // 计算in[block] = U outBB[predBB];
        std::set<int> in[2];
        if (block->getNumOfPred() > 0)
            in[0] = outBB[*block->pred_begin()];
        auto it = block->pred_begin();
        it++;
        int turn = 1;
        for (; it != block->pred_end(); it++)
        {
            in[turn].clear();
            std::set_intersection(outBB[*it].begin(), outBB[*it].end(), in[turn ^ 1].begin(), in[turn ^ 1].end(), inserter(in[turn], in[turn].begin()));
            turn ^= 1;
        }
        inBB[block] = in[turn ^ 1];
        // 计算outBB[block] = (inBB[block] - killBB[block]) U genBB[block];
        std::set<int> midDif;
        std::set<int> out;
        std::set_difference(inBB[block].begin(), inBB[block].end(), killBB[block].begin(), killBB[block].end(), inserter(midDif, midDif.begin()));
        std::set_union(genBB[block].begin(), genBB[block].end(), midDif.begin(), midDif.end(), inserter(out, out.begin()));
        if (out != outBB[block])
        {
            outBB[block] = out;
            for (auto succ = block->succ_begin(); succ != block->succ_end(); succ++)
                workList.insert(*succ);
        }
    }
}

bool IRComSubExprElim::removeGlobalCSE(Function *func)
{
    // 计算gen、kill、in和out
    calGenKill(func);
    calInOut(func);

    // 标记是否发生了变化，用于判断是否需要继续迭代
    bool changed = false;

    // 获取函数的基本块列表
    std::vector<BasicBlock*> blocks = func->getBlockList();
    // 遍历每个基本块
    for (BasicBlock *bb : blocks)
    {
        // 获取基本块内的指令列表
        std::vector<Instruction*> instructions = bb->getInstructionList();
        // 遍历每条指令
        for (Instruction *inst : instructions)
        {
            // TODO: 根据计算出的gen、kill、in和out进行全局公共子表达式消除的逻辑
            // 这可能涉及到比较gen、kill、in和out集合，判断是否可以进行子表达式消除

            // 示例：假设gen和in集合相同，则可以考虑消除子表达式
            if (genBB == inBB)
            {
                // 进行全局公共子表达式消除的操作
                // 根据实际情况修改
                inst->remove();
                changed = true;
            }
        }
    }
    // 如果发生了变化，可能需要继续迭代，根据具体情况决定是否返回true
    return changed;
}

void IRComSubExprElim::pass()
{
    for (auto func = unit->begin(); func != unit->end(); func++)
    {
        while (!localCSE(*func) || !globalCSE(*func))
            ;
    }
}
